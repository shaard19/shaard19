//Section 3
#include <iostream>

using namespace std;

int main()
  {
 //Variable declaration
    int grade; 
	int sum;
	float average;
     cout << "Enter Grade: ";
    cin >> grade;
    //iteration loop
for (int i = 1; i <=9; ++i) 
{
        sum += grade;
        average=sum/10;
        cout << "Enter Grade: ";
        cin >> grade;
}
cout << "The  total of 10 grades is" << sum << endl;
cout << "The  class average is " << average << endl;
    return 0;
}