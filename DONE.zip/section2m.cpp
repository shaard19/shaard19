//section 2
#include <iostream>

using namespace std;
int main ()

{   
int i;
int k;
   for( int k = 1, i = 10;  k< 5; k = k + 1, i = i - 2 )
   {
       cout << "value of k: " << k << endl;
       cout << "value of i: " << i << endl;
   } 
   return 0;

}