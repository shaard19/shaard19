//Section 1
#include <iostream>
using namespace std;

int main()
 {
 //Variable declaration
    int marks; 
	int sum;
	float average;
     cout << "Enter Student marks: ";
    cin >> marks;
    //iteration loop
for (int i = 1; i <=9; ++i) 
{
        sum += marks;
        average=sum/10;
        cout << "Enter Student marksr: ";
        cin >> marks;
}
cout << "The  overal Class total is " << sum << endl;
cout << "The  class average is " << average << endl;
    return 0;
}